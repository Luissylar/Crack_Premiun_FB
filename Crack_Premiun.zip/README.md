## COMMAND :

[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&color=FF2C10&background=31FF9400&width=435&lines=File+And+Random+FB+id+Cracking+Tool+Enjoy%F0%9F%A4%9F)](https://git.io/typing-svg)

* `pkg update && pkg upgrade`

* `pkg install python`

* `pkg install git`

* `pip install requests`

* `pip install mechanize`

* `pip install futures`

* `pip install urllib3`

* `pip install rich`

* `pip install bs4`

* `rm -rf ULTRA-CRACK`

* `git clone https://github.com/MUMIT-404-CYBER/ULTRA-CRACK.git`

* `cd ULTRA-CRACK`

* `python Green.py`



___This Tool is Free Enjoy Dear User.___</br>

## SCREENSHOT :
<br>
<p align="center">
<img src="__scr__/ultra.jpg"/>
</p>
